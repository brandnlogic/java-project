package com;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class SetterGetter 
{
	InsertValue iv=new InsertValue();
	public String getBoard() {
		return board;
	}
	public void setBoard(String board) {
		this.board = board;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSchool_name() {
		return school_name;
	}
	public void setSchool_name(String school_name) {
		this.school_name = school_name;
	}
	public String getNo_student() {
		return no_student;
	}
	public void setNo_student(String no_student) {
		this.no_student = no_student;
	}
	public String getNo_staff() {
		return no_staff;
	}
	public void setNo_staff(String no_staff) {
		this.no_staff = no_staff;
	}
	public String getNo_faculty() {
		return no_faculty;
	}
	public void setNo_faculty(String no_faculty) {
		this.no_faculty = no_faculty;
	}
	public String getNo_computer() {
		return no_computer;
	}
	public void setNo_computer(String no_computer) {
		this.no_computer = no_computer;
	}
	public String getComputer_aided() {
		return computer_aided;
	}
	public void setComputer_aided(String computer_aided) {
		this.computer_aided = computer_aided;
	}
	public String getContact_person() {
		return contact_person;
	}
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}
	public String getContact_mail_id() {
		return contact_mail_id;
	}
	public void setContact_mail_id(String contact_mail_id) {
		this.contact_mail_id = contact_mail_id;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	private String board;
    private String type;
    private String school_name;
    private String no_student;
    private String no_staff;
    private String no_faculty;
    private String no_computer;
    private String computer_aided;
    private String contact_person;
    private String contact_mail_id;
    private String contact_no;
    private String address;
    private String latitude;
    private String longitude;
    
//    private String name()
//    {
//    	return board;
//		
//	}
    
    public void insert_Value()
    {
    	 String csvFile = "C:/Users/user/Downloads/book1.csv";
         BufferedReader br = null;
         String line = " ";
         String cvsSplitBy = ",";
         
         
         try {

             br = new BufferedReader(new FileReader(csvFile));
             while ((line = br.readLine()) != null) {

                 // use comma as separator
                 String[] Book1 = line.split(cvsSplitBy);
                 //System.out.println(b);
                // b++;
//                 System.out.println(Book1[0]+"  "+ Book1[1] +"   " + Book1[2] +"   "+ Book1[3] + "  " + Book1[4] + "  " + Book1[5] + "  "
//                   		+ "  " + Book1[6] + "  " + Book1[7] + "  " + Book1[8] + "  " + Book1[9] + "  " + Book1[10]+ "  " + Book1[11]+ "  "+
//                 		Book1[12]+ "  " + Book1[13] );
                 
                 board=Book1[0];
                 type=Book1[1];
                 school_name=Book1[2];
                 no_student=Book1[3];
                 no_staff=Book1[4];
                 no_faculty=Book1[5];
                 no_computer=Book1[6];
                 computer_aided=Book1[7];
                 contact_person=Book1[8];
                 contact_mail_id=Book1[9];
                 contact_no=Book1[10];
                 address=Book1[11];
                 latitude=Book1[12];
                 longitude=Book1[13];
                 
                // System.out.println(longitude);
                 iv.subs();
               
             }
             } catch (FileNotFoundException e1) {
                 e1.printStackTrace();
             } catch (IOException e1) {
                 e1.printStackTrace();
             } finally {
                 if (br != null) {
                     try {
                         br.close();
                     } catch (IOException e) {
                         e.printStackTrace();
                     }
                 }
             }

    }

}
