package com;

public class Main 
{
public static void main(String[] args) {
		
		SetterGetter sg=new SetterGetter();
		 sg.insert_Value();
	}


}
