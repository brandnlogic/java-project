package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertValue {
	
	static SetterGetter sg=new SetterGetter();
	Connection con = null;
	String url="jdbc:mysql://127.0.0.1:3306/school";
	String userName="root";
	String password = "";
	public void subs()
	{
		//System.out.println("the board val:-" + sg.getBoard() );
		String board=sg.getBoard();
		String type=sg.getType();
	    String school_name=sg.getSchool_name();
	    String no_student=sg.getNo_student();
	    String no_staff=sg.getNo_staff();
	    String no_faculty=sg.getNo_faculty();
	    String no_computer=sg.getNo_computer();
	    String computer_aided=sg.getComputer_aided();
	    String contact_person=sg.getContact_person();
	    String contact_mail_id=sg.getContact_mail_id();
	    String contact_no=sg.getContact_no();
	    String address=sg.getAddress();
	    String latitude=sg.getLatitude();
	    String longitude=sg.getLongitude();
	    
	    
//	    System.out.println(longitude);
//	    System.out.println(address);
		try{
			//Loading driver
			Class.forName("com.mysql.cj.jdbc.Driver");
//			System.out.println("classforname");
			//creating connection
			//Connection con = DriverManager.getConnection("jdbc:mysql://3306/school","root","");
			 con = DriverManager.getConnection(url,userName,password);
			 //System.out.println(con);
			PreparedStatement pst=con.prepareStatement("insert into information (board,type,school_name,no_student,no_staff,no_faculty,no_computer,"
					+ "computer_aided,contact_person,contact_mail_id,contact_no,address,latitude,longitude) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			   
			         pst.setString(1,board);
			         //System.out.println(board);
			         pst.setString(2,type);
			         pst.setString(3,school_name);
			         pst.setString(4,no_student);
			         pst.setString(5,no_staff);
			         pst.setString(6,no_faculty);
			         pst.setString(7,no_computer);
			         pst.setString(8,computer_aided);
			         pst.setString(9,contact_person);
			         pst.setString(10,contact_mail_id);
			         pst.setString(11,contact_no);
			         pst.setString(12,address);
			         pst.setString(13,latitude);
			         pst.setString(14,longitude);
			         int result=pst.executeUpdate();
			         
			         System.out.println(result+"insert Successfully");
//			         System.out.println(longitude+"hii hallo");
//			    System.out.println(result+"dhduh jdfjhgiduhu dbjdh dfhbgjuhd dhhgdh");
//				    System.out.println("jkhjkh uhhh ui hiuh uhiuh ");

			        
			}catch(Exception e){
//			System.out.println("error message-" + e.getMessage() + " " + e.getLocalizedMessage());
			e.fillInStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // closing connection
		}

	}
	
	
	public static void main(String[] args) {
		
		
		 sg.insert_Value();
	}

}
